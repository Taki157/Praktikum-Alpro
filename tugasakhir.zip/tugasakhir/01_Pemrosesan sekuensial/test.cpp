// Filbert Ganteng

#include <cstdio>

int main(){
    int n, median = 0, arr[1001];
    char carr[1001];
    scanf("%d", &n);
    for (int i = 0; i < n; i++)
    {
        printf("Masukan nilai tabel: ");
        scanf("%d", &arr[i]);
        median += arr[i];
        if (arr[i] >= 80) carr[i] = 'A';
        else if (arr[i] >= 70) carr[i]  = 'B';
        else if (arr[i] >= 55) carr[i] = 'C';
        else if (arr[i] >= 40) carr[i] = 'D';
        else carr[i] = 'E'; 
    }  
    float med = (float)median/n;
    for (int i = 0; i < n; i++)
    {
        printf("%c ", carr[i]);
    }
    printf("\nmedian dari nilai tabel: %.2f", med);
}