#include <cstdio>

void tabUrut(int arr[], int length);
void print(int arr[101], int length);

int main(){
    int length, X, IX, arr[101];
    scanf("%d", &length);
    for (int i = 1; i <= length; i++) { // Tidak Perlu ditulis
        scanf("%d", &arr[i]);
    }
    tabUrut(arr, length); // Tidak perlu ditulis
    scanf("%d", &X);
    arr[length + 1] = X;
    int i = 1;
    while (i < length && arr[i] > X) {
        i++;
    }
    (arr[i] == X) ? IX = i : IX = 0; // IX = 0 jika tidak ada
    printf("%d", IX); // Tidak Perlu ditulis
}


// Tidak perlu ditulis
void tabUrut(int arr[], int length){
    for (int i = 1; i <= length; i++)
    {
        for (int j = i+ 1; j <= length; j++)
        {
            if (arr[i] < arr[j])
            {
                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
    }
}

//Tidak perlu ditulis
void print(int arr[101], int length){
    for (int i = 0; i <= length; i++) {
        printf("%d ", arr[i]);
    }
}