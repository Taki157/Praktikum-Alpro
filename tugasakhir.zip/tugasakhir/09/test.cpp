#include <iostream>

using namespace std;
struct peloncat{
    int jum_loncatan;
    int skor;
};
struct peloncat peserta[10];
int main(){
    while (){
        cout << "Peserta yang ingin meloncat: ";
        
    }
}